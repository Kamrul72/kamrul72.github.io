module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "kamrul",
    DB: "entries"
  };